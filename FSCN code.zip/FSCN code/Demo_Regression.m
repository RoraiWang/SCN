% Demo Data regression of SCN
clear;
clc;
close all;
format long;
tic;
%%  Prepare the training (X, T) and test data (X2, T2) 
% X: each row vector represents one sample input.
% T: each row vector represents one sample target.
% same to the X2 and T2.
% Note: Data preprocessing (normalization) should be done before running the program.
load('Diff_Data.mat');
load('data.mat');   
%[h1,pValue1,stat1,cValue1,reg1]=  adftest(Outputdata1);
%% Parameter Setting
L_max = 150;                    % maximum hidden node number
tol = 0.0001;                    % training tolerance
T_max = 100;                    % maximun candidate nodes number
Lambdas = [0.5, 1, 5, 10, ...
    30, 50, 100, 150, 200, 250];% scope sequence
r =  [ 0.9, 0.99, 0.999, ...
    0.9999, 0.99999, 0.999999]; % 1-r contraction sequence
nB = 1;       % batch size

%% Model Initialization
M = SCN(L_max, T_max, tol, Lambdas, r , nB);
disp(M);

%% Model Training
% M is the trained model
% per contains the training error with respect to the increasing L
[M, per] = M.Regression(Difference_X, Difference_T);
disp(M);

%% Training error demo
figure;
plot(per.Error, 'r.-');
xlabel('L');
ylabel('RMSE');
legend('Training RMSE');

Difference_X3=[Difference_X;Difference_X2]
T3=[T;T2];
%% Model output vs target on training dataset
A=Difference_X3;
O1 = M.GetOutput(A);
d=dT;
n1 = size(O1);
n=n1(1);
%n 是pre的个�?
%%%�?个n*1阶的零矩�?
F = zeros(n,1);
W = O1;
X2 = zeros(n,1);
%%%这里的问题是gamma�?170）就会出现超出限制的问题
for k=1:150
    F(k)= gamma(k-d) / (gamma(k+1) * gamma(-d));
end

%下面是反差分的公式W是差分后的数据X是原始数据（�?要还原后的数据）
for i = 1 : n
    for j = 1 : i
        if i > j  
            W(i) =W(i) - F(j+1)*X2(i-j);   
        else
            continue;    
        end
    end 
    X2(i) = W(i) / F(1); 
end

Outresult=-X2(1:60000,:);
Outresult2=-X2(60001:100000,:);

figure;
plot(1:60000,T, 'r.-',1:60000,Outresult, 'b.-'); 
xlabel('X');
ylabel('Y');
legend('Training Target', 'Model Output');
E = T - Outresult; 
MSE=mse(E);
RMSE=sqrt(MSE);
MAE=mae(E);
MAPE=100*mae(E./Outresult);
VAR=var(E);

%% Model output vs target on test dataset
figure;
plot(1:40000,T2, 'r.-',1:40000,Outresult2, 'b.-'); 
xlabel('X');
ylabel('Y');
legend('Test Target', 'Model Output');
E2 = T2 - Outresult2; 
MSE2=mse(E2);
RMSE2=sqrt(MSE2);
MAE2=mae(E2);
MAPE2=100*mae(E2./Outresult2);
VAR2=var(E2);
toc;
disp(['����ʱ��: ',num2str(toc)]);
%save 20200801.mat
disp('�������')