clc
clear
load data1.mat
tic;
TG=mapminmax(T',0,1)';
TG2=mapminmax(T2',0,1)';
T=TG;
T2=TG2;


XZ=[X;X2];
a1=XZ(:,1);
a2=XZ(:,2);
a3=XZ(:,3);
a4=XZ(:,4);
a5=XZ(:,5);
a6=XZ(:,6);
a7=XZ(:,7);
a8=XZ(:,8);
a9=XZ(:,9);
a10=XZ(:,10);
a11=XZ(:,11);
a12=XZ(:,12);
a13=XZ(:,13);
a14=XZ(:,14);
a15=XZ(:,15);
XG1=mapminmax(a1',0,1)';
XG2=mapminmax(a2',0,1)';
XG3=mapminmax(a3',0,1)';
XG4=mapminmax(a4',0,1)';
XG5=mapminmax(a5',0,1)';
XG6=mapminmax(a6',0,1)';
XG7=mapminmax(a7',0,1)';
XG8=mapminmax(a8',0,1)';
XG9=mapminmax(a9',0,1)';
XG10=mapminmax(a10',0,1)';
XG11=mapminmax(a11',0,1)';
XG12=mapminmax(a12',0,1)';
XG13=mapminmax(a13',0,1)';
XG14=mapminmax(a14',0,1)';
XG15=mapminmax(a15',0,1)';

XG=[XG1,XG2,XG3,XG4,XG5,XG6,XG7,XG8,XG9,XG10,XG11,XG12,XG13,XG14,XG15];
X=XG(1:60000,:);
X2=XG(60001:100000,:);
toc;
disp(['����ʱ��: ',num2str(toc)]);
save("data.mat","T","T2","X","X2")
disp("END")