clear;
clc;
close all;
format long;
tic;
filename = 'ethylene_methane.csv';
inputdata = csvread(filename,1,0,[1,0,100000,14]);
Outputdata = csvread(filename,1,15,[1,15,100000,15]);
[h,pValue,stat,cValue,reg]=  adftest(Outputdata);
x=(1:1:100000)';
[h1,pValue1,stat1,cValue1,reg1]=  adftest(Outputdata);
h1
X=inputdata(1:60000,:);
X2=inputdata(60001:100000,:);
T=Outputdata(1:60000,:);
T2=Outputdata(60001:100000,:);
save('data.mat','X','T','X2','T2')
disp('�������н���')
toc;
disp(['����ʱ��: ',num2str(toc)]);
